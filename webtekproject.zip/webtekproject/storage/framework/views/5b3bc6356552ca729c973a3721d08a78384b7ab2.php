<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
<h1>Please Fill up Necessary Information</h1>
</body>
</html>